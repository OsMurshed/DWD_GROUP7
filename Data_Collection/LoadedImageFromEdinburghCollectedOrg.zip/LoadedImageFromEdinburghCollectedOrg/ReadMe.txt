To make sure you are connected to the internet and press LoadImageFromEdinburghCollectedOrg.exe

you cmd window going to pop up then it going to download the images in a folder with name "LoadImageFromEdinburghCollectedOrg"

please, wait until it finishes it might take time (depend on in your internet speed), the total image is 1090.